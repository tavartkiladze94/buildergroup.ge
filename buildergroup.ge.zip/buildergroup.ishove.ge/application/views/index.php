<?php
/*
error_reporting(E_ALL);
$this->load->view('layouts/header');
$this->load->view($content);
		// $this->load->view('include/sidebar');
$this->load->view('layouts/footer');
*/
