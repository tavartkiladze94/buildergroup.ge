<br>
<br>
 <section class="banner_area">
            <div class="container">
                <div class="banner_inner_text">
                    <h4><?=$this->lang->line('Contact');?></h4>
                    <ul>
                        <li><a href="#"><?=$this->lang->line('Home');?></a></li>
                        <li class="active"><a href="#"><?=$this->lang->line('Contact');?></a></li>
                    </ul>
                </div>
            </div>
        </section>
  <section class="address_area" style="margin-top:150px;">
            <div class="container">
                <div class="row address_inner">
                    <div class="col-md-4">
                        <div class="media">
                            <div class="media-left">
                                <img src="img/icon/place-icon.png" alt="">
                            </div>
                            <div class="media-body">
                                <h4><?=$this->lang->line('Address');?> :</h4>
                                <h5> ქალაქი ბათუმი,  ჭავჭავაძის ქ. <font style="font-size:14:px;"> 78/8 </font> ბინა <font style="font-size: 14:px;"> 6 </font</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="media">
                            <div class="media-left">
                                <img src="img/icon/phone-icon.png" alt="">
                            </div>
                            <div class="media-body">
                                
                                <h5>(995) 557 15 65 65</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="media">
                            <div class="media-left">
                                <img src="img/icon/inbox-icon.png" alt="">
                            </div>
                            <div class="media-body">
                                <h5>info@bestbuildergroup.com</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php echo $map['js']; ?>
<div  class="mapp">

   
    <?php echo $map['html']; ?>
      

    </div>
