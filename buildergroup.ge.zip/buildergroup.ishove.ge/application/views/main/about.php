

       
        <!--================Header Area =================-->
        <br>
        <br>
        <br>
<section class="banner_area">
            <div class="container">
                <div class="banner_inner_text">
                    <h4><?=$this->lang->line('About us');?></h4>
                    <ul>
                        <li><a href="#"><?=$this->lang->line('Home');?></a></li>
                        <li class="active"><a href="#"><?=$this->lang->line('About us');?></a></li>
                    </ul>
                </div>
            </div>
        </section>
<section class="project_single_area" >
            <div class="container">
                <div class="project_single_inner">
                   
                    <div class="row" style="padding:5px;">
                        <br>
                        <br>
                        <?php echo $about_text[$this->lang->line('about_text')];?>
                        <br>

                    </div>
                </div>
            </div>
        </section>