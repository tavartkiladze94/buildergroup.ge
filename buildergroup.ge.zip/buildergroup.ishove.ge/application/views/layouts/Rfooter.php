	<!-- jQuery first, then Popper.js, then Bootstrap JS -->

	<script src="<?=base_url();?>assetsbest/admin/js/popper.min.js"></script>
	<script src="<?=base_url();?>assetsbest/admin/js/bootstrap.min4.2.1.js"></script>
	<script src="<?=base_url();?>assetsbest/admin/js/customscriptfile.js"></script>
	
</body>

</html>