<!DOCTYPE html>
<html>
<body>

<p>Click on the "Choose File" button to upload a file:</p>

<form action="<?=base_url('admin/update_finansebi_gallery');?>">
  <input type="file"  name="file_name">
  <input type="submit">
</form>

</body>
</html>
