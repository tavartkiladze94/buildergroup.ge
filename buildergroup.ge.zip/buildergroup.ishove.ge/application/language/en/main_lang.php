<?php
$lang['en_US'] = 'en_US';
$lang['Lang'] ='EN';

$lang['Georgian'] = 'GE';
$lang['language'] = 'English';

$lang['Russian'] = 'RU';
$lang['English'] = 'EN';
$lang['read more'] = 'read more';
$lang['View more'] = 'View more';
$lang['Home'] = 'Home';
$lang['Apartment'] = 'Apartment';
$lang['Black_frame'] = 'Black frame';
$lang['Villa'] = 'Villa';
$lang['News'] = 'News';
$lang['Hotel'] = 'Hotel';
$lang['Photo'] = 'Photo';
$lang['Title'] = 'Title';
$lang['Resort_hotel'] = 'Resort hotel';
$lang['Guest_hotel'] = 'Guest hotel';
$lang['Room'] = 'Room';
$lang['Flat'] = 'Flat';
$lang['Cottage'] = 'Cottage';
$lang['Tour'] = 'Tour';
$lang['Adjara'] = 'Adjara';
$lang['Guria'] = 'Guria';
$lang['Imereti'] = 'Imereti';
$lang['Samegrelo'] = 'Samegrelo';
$lang['Svaneti'] = 'Svaneti';
$lang['Samtskhe_Javakheti'] = 'Samtskhe-Javakheti';
$lang['Kvemo Kartli'] = 'Kvemo Kartli';
$lang['Kakheti'] = 'Kakheti';
$lang['Car'] = 'Car';
$lang['About us'] = 'About us';
$lang['Information']='Information';
$lang['Gallery'] = 'Gallery';
$lang['Frequently ask question'] = 'Frequently ask question';
$lang['Contact'] ='Contact';
$lang['Contact us'] ='Contact us';
$lang['Buy it'] ='Buy it';
$lang['Load more'] ='Load more';
$lang['Family type houses'] = 'Family type houses';
$lang['Rooms'] ='Rooms';
$lang['Tours'] ='Tours';
$lang['Offered cars'] ='Offered cars';
$lang['What do you think about us?'] ='What do you think about us?';
$lang['Company'] = '';
$lang['Address'] ='Address';
$lang['Email'] = 'Email';
$lang['Contact number'] = 'Contact number';
$lang['Batumi,  Maiakovski st. 17'] = 'Batumi,  Maiakovski st. 17';
$lang['Best price quarantee'] = 'Best price quarantee';
$lang['Security and insurance'] = 'Security and insurance';
$lang['The best travel agency'] = 'The best travel agency';
$lang['Best condition'] = 'Best condition';
$lang['Search'] = 'Search';
$lang['Filter'] ='Filter';
$lang['Find your comfort environment'] = 'Find your comfort environment';
$lang['lang'] = 'ENG';
//---------------------------------------------
$lang['Register']='Register';
$lang['Registrator']='Registrator';
$lang['Privacy policy']='Privacy policy';
$lang['Name'] = 'Name';
$lang['Surname'] = 'Lastname';
$lang['Username'] = 'Username';
$lang['I agree to']='I agree to';
$lang['Password'] = 'Password';
$lang['Repeat password'] ='Repeat password';
$lang['Repeat'] ='Repeat';
$lang['remember']='remember';
$lang['Forgot your password?'] = 'Forgot your password?';
$lang['Already Have An Account?'] = 'Already Have An Account ?';
$lang['Go through the authentication and use the consumer functions'] = 'Go through the authentication and use the consumer functions';
$lang['Log in'] = 'Log In';


$lang['Control panel'] ='Control panel';
$lang['Sign out'] ='Sign out';
$lang['Current password is incorrect'] ='Current password is incorrect';
$lang['incorrect credentials'] ='Incorrect credentials';
$lang['Messages'] ='Messages';
$lang['View all'] ='View all';
$lang['Notifications'] ='otifications';
$lang['Control panel'] ='Control panel';
$lang['View profile'] ='View profile';
$lang['Edit profile'] ='Edit profile';
$lang['Change password'] ='Change password';
$lang['Users'] ='Users';
$lang['User'] ='User';
$lang['Controller'] ='Controller';
$lang['Admin'] ='Admin';
$lang['Create user'] ='Create user';
$lang['List'] ='List';
$lang['Listing'] ='Listing';
$lang['Create'] ='Create';
$lang['All'] ='All';
$lang['Active'] ='Active';
$lang['Expired'] ='Expired';
$lang['Booking'] ='Booking';
$lang['Approved'] ='approved';
$lang['Pending'] ='Pending';
$lang['Canceled'] ='Canceled';
$lang['Profile'] ='Profile';
$lang['Edit'] ='Edit';

$lang['Users'] ='Users';
$lang['Users list'] ='Users list';
$lang['Status'] ='Status';
$lang['Action'] ='Action';
$lang['Show'] ='Show';
$lang['Previous'] ='Previous';
$lang['Next'] ='Next';

// profile_edit
$lang['Personal No'] ='Personal No';
$lang['City'] ='City';
$lang['Telephone'] ='Telephone';
$lang['Save'] ='Save';
$lang['Cancel'] ='Cancel';
$lang['Your photo'] ='Your photo';
$lang['Photo'] =' Photo';
$lang['Images'] =' Images';
$lang['Details'] ='Details';
$lang['Drop files here or click to upload.'] ='Drop files here or click to upload.';
$lang['Old password'] ='Old password';
$lang['New password'] ='New password';
$lang['Update'] ='Update';
$lang['Add new'] ='Add new';
$lang['Add details'] ='Add details';
$lang['Number'] ='Number';
$lang['Category'] ='Category';
$lang['Choose'] ='Choose';
$lang['Floor'] ='Floor';
$lang['Area'] ='Area';
$lang['Number of rooms'] ='Number of rooms';
$lang['Distance from the sea'] ='Distance from the sea';

$lang['Owner'] ='Owner';

$lang['Environment']='Environment';
$lang['Service'] ='Service';
$lang['Cleanup'] ='Cleanup';
$lang['Meal'] ='Meal';
$lang['Washing'] ='Washing';
$lang['TV'] ='TV';
$lang['Refrigerator'] ='Refrigerator';
$lang['Wifi'] ='Wifi';
$lang['Air conditioner'] ='Air Conditioner';
$lang['Washing machine'] ='Washing machine';
$lang['Hair dryer'] ='Hair dryer';
$lang['Iron'] ='Iron';
$lang['Heating'] ='Heating';
$lang['Gas'] ='Gas';
$lang['No'] ='No';
$lang['Central_heating'] ='Central heating';
$lang['Table'] ='Table';
$lang['Furniture'] ='Furniture';
$lang['Closet'] ='Closet';
$lang['Service'] ='Service';
$lang['Parking'] ='Parking';
$lang['Yard'] ='Yard';
$lang['Result'] ='Result';
$lang['Garden'] ='Garden';
$lang["Children's environment"] ="Children's environment";
$lang['Restaurant_cafe'] ='Restaurant/cafe';
$lang['Swimming pool'] ='Pool';
$lang['Description'] ='Description';
$lang['Price'] ='price';
$lang['Without_cleanup'] ='Without cleanup';
$lang['Without_meal'] ='Without meal';
$lang['Without_washing'] ='Without washing';
$lang['Cleanup_agreement'] ='Cleanup agreement';
$lang['Washing_agreement'] ='Washing agreement';
$lang['Meal_agreement'] ='Meal agreement';
$lang['Date'] = 'Date';
$lang['Code'] = 'Code';
$lang['Cadastral code'] = 'Cadastral code';
$lang['Breakfast'] = 'Breakfast';
$lang['Dinner'] = 'Dinner';
$lang['Supper'] = 'Supper';
$lang['Breakfast_Dinner'] = 'Breakfast+Dinner';
$lang['Dinner_Supper'] = 'Dinner+Supper';
$lang['Breakfast_Dinner_Supper'] = 'Breakfast+Dinner+Supper';

$lang['Title'] = 'Title';
$lang['Choose'] = 'Choose';

$lang['Model'] = 'Model';
$lang['Rent_type'] = 'Rent type';
$lang['for_sale'] = 'For Sale';
$lang['for_rent'] = 'For Rent';
$lang['Rent type'] = 'Rent type';
$lang['Daily'] = 'daily';
$lang['Agreement'] = 'Agreement';
$lang['Manufacturer'] = 'Manufacturer';
$lang['Year'] = 'Year';
$lang['Engine'] = 'Engine';
$lang['Transmission'] = 'Transmission';
$lang['Manual'] = 'Manual';
$lang['Automatic'] = 'automatic';
$lang['Tiptronic'] = 'Tiptronic';
$lang['Variator'] = 'Variator';
$lang['Fuel_type'] = 'Fuel type';
$lang['Petrol'] = 'Petrol';
$lang['Diesell'] = 'Diesel';
$lang['Hybrid'] = 'Hybrid';
$lang['CNG'] = 'CNG';
$lang['LPG'] = 'LNG';
$lang['Wheel'] = 'Wheel';
$lang['Left_wheel'] = 'Left wheel';
$lang['Right-hand_wheel'] = 'Right-hand wheel';
$lang['Capacity'] = 'Capacity';
$lang['Driver'] = 'Driver';
$lang['With_driver'] = 'With driver';
$lang['Without_driver'] = 'Without driver';
$lang['record successfully added'] = 'record successfully added';
$lang['Settings'] = 'Settings';
$lang['Delete'] = 'Delete';
$lang['Set as main'] = 'Set as main';
$lang['Sort By Filter'] = 'Sort By Filter';
$lang['Select Category'] = 'Select Category';
$lang['Currency converter'] = 'Currency converter';
$lang['type'] = 'type';
$lang['Rent'] = 'Rent';
$lang['Sell'] = 'Sell';
$lang['Pledge'] = 'Pledge';
$lang['Rent1'] = 'Rent';
$lang['Buy'] = 'Buy';
$lang['Mortgage'] = 'Mortgage';
$lang['Land'] = 'Land';
$lang['Office'] = 'Office';
$lang['Restaurant/cafe'] = 'Restaurant/cafe';
$lang['Warehouse'] = 'Warehouse';
$lang['Magazine'] = 'Magazine';
$lang['Com. space'] = 'Com. space';


$lang['Services'] = 'Services';
$lang['Search it'] = 'Search it';
$lang['Book it'] = 'Book it';
$lang['Travel'] = 'Travel';
$lang['Best tours in Georgia'] = 'Best tours in Georgia';
$lang['Best Hotels'] = 'Best Hotels';
$lang['Best Cars'] = 'Best Cars';
$lang['Travel Guides'] = 'Travel Guides';
$lang['Location Manager'] = 'Location Manager';
$lang['Best Travel Agent'] = 'Best Travel Agent';
$lang['Activate'] = 'Activate';
$lang['Expire'] = 'Expire';

$lang['Period'] = 'Perod';
$lang['Room'] = 'Room';
$lang['Gas'] = 'Gas';
$lang['Bed'] = 'Bed';
$lang['Villa'] = 'Villa';
$lang['Free breakfast'] = 'Free breakfast';
$lang['Wheelchair access'] = 'Wheelchair access';
$lang['Taxi available'] = 'Taxi available';
$lang['Secure'] = 'Secure';
$lang['Bar'] = 'Bar';
$lang['Kitchen'] = 'Kitchen';
$lang['Bathroom'] = 'Bathroom';
$lang['Balcony'] = 'Balcony';
$lang['Near to central way'] = 'Near to central way';
$lang['Near to city'] = 'Near to city';
$lang['Near to sea'] = 'Distance from sea';
$lang['Near to river'] = 'Near to river';
$lang['Near to lake'] = 'Near to lake';
$lang['Near to mount'] = 'Near to mount';
$lang['Near to hospital'] = 'Near to hospital';
$lang['Playground'] = 'Playground';
$lang['Pets allowed'] = 'Pets allowed';
$lang['2 bed'] = 'ორ საწოლიანი';
$lang['3 bed'] = 'სამ საწოლიანი';
$lang['4 bed'] = 'ოთხ საწოლიანი';
$lang['5 bed'] = 'ხუთ საწოლიანი';
$lang['Top Resorts'] = 'Top Resorts';
$lang['Bedroom'] = 'Bedroom';
$lang['Batumi'] = 'Batumi';
$lang['Sarfi'] = 'Sarfi';
$lang['Kobuleti'] = 'Kobuleti';
$lang['Kvariati'] = 'Kvariati';
$lang['Gonio'] = 'Gonio';
$lang['Region'] = 'Region';
$lang['Mtskheta_Mtianeti'] = 'Mtskheta-Mtianeti';
$lang['Season'] = 'Season';
$lang['Summer'] = 'Summer';
$lang['Autumn'] = 'Autumn';
$lang['Winter'] = 'Winter';
$lang['Spring'] = 'Spring';


$lang['Subscribe'] = 'Subscribe';
$lang['Subscribe to our newsletter'] = 'Subscribe to our newsletter';
$lang['Rooms'] = 'Rooms';
$lang['Apartments'] = 'Apartments';
$lang['Reviews'] = 'Reviews';
$lang['View'] = 'View';
$lang['Map'] = 'Map';
$lang['Write review'] = 'Write review';
$lang['Top_speed'] = 'Top speed';
$lang['km/h'] = 'km/h';
$lang['m/h'] = 'm/h';
$lang['Where'] = 'Where';
$lang['Location'] = 'Location';
$lang['Adult'] = 'Adult';
$lang['Child'] = 'Child';
$lang['Night'] = 'Night';
$lang['duration'] = 'duration';
$lang['Duration'] = 'Duration';
$lang['optional'] = 'optional';
$lang['Choose it'] = 'Choose it';
$lang['Find it'] = 'Find it';
$lang['How does it work'] = 'How does it work';
$lang['House'] = 'House';
$lang['New_building_apartment'] = 'New Building Apartment';
$lang['Old_building_apartment'] = 'Old Building Apartment';
$lang['Under_construction_apartment'] = 'Under Construction Apartment';
$lang['Agricultural_land'] = 'Agricultural Land';
$lang['Non_agricultural_land'] = 'Non-Agricultural Land';
$lang['Day'] = 'Day';
$lang['Free'] = 'Free';
$lang['Type'] = 'Type';
$lang['Object'] = 'Object';
$lang['I agree to'] = 'I agree to';
$lang['Email Validation'] = 'Email Validation';
$lang['Confirmation code sent on your email'] = 'Confirmation code sent on your email';
$lang['Useful links'] = 'Useful links';
$lang['Password recovery'] = 'Password recovery';
$lang['Or'] = 'Or';
$lang['Recovery'] = 'Recovery';
$lang['New password'] = 'New password';
$lang['Advanced Search'] = 'Advanced Search';
$lang['Min. Area'] = 'Min. Area';
$lang['Max. Area'] = 'Max. Area';
$lang['Min. Price'] = 'Min. Price';
$lang['Max. Price'] = 'Max. Price';
$lang['Min. Floor No'] = 'Min. Floor No';
$lang['Max. Floor No'] = 'Max. Floor No';
$lang['Elevator'] = 'Elevator';
$lang['M'] = 'm';
$lang['Main page'] = 'Main page';
$lang['projects'] ='Projects';
$lang['project'] ='Project';

$lang['Current projects'] ='Current Projects';

$lang['Office_address'] = 'Chavchavadze 78/88, apartment 6';





$lang['about_us_text'] ='კომპანია შპს ბესთ ბილდინგ-ი დაფუძნდა 2020 წლის 24 მარტს, კომპანია აერთიანებს იმ ადამიანების ჯგუფს, რომლებიც ბოლო 10-12 წლის  განმავლობაში საქართველოს სხვა და სხვა რეგიონებში აწარმოებდნენ და უშუალოდ მონაწილეობას ღებულობდნენ  სამშენებლო სარემონტო საპროექტო სამუშაოებში.
კომპანიას გააჩნია გამოცდილი თანამშრომლები, როგორც სამშენებლო ასევე ადმინისტრაციულ რგოლში. კომპანია ორიეტირებულია ხარისხზე და დროზე, ასევე დიდი ყურადღება ექცევა უსაფრთხოების განყოფილებას. ყოველ ობიექტს მინიმუმ ორი უსაფრთხოების თანამშრომელი ყავს მიმაგრებული.
შპს ,,ბესთ ბილდინგი“-ს მთავარი მიზანია საკუთარი სიტყვა თქვას სამშენებლო სფეროში.
';

$lang['Blog'] = 'Blog';
$lang['title_lang'] = 'title_en';
$lang['text_short_lang'] = 'text_short_en';
$lang['text_full_lang'] = 'text_full_en';
$lang['Who we are?'] = 'Who we are?';
$lang['Construction company'] = 'Construction company';
$lang['Looking for a quality and affordable constructor for your next project?'] = 'Looking for a quality and affordable constructor for your next project?';

$lang['Our Team'] = 'Our Team';
$lang['Why choose us?'] = 'Why choose us?';
$lang['Our Projects'] = 'Our Projects';
$lang['J. Shartava'] = 'J. Shartava';
$lang['Repair'] = 'Repair';
$lang['Renovation'] = 'Renovation';
$lang['Plumbing'] = 'Plumbing';

$lang['Construction'] = 'Construction';
$lang['Building'] = 'Building';
$lang['Construction_scaffolding'] = 'Construction scaffolding';
$lang['Construction_stand'] = 'Construction stand';
$lang['Column_forming_material'] = 'Column forming material';
$lang['Wall_formwork_material'] = 'Wall formwork material';
$lang['Roofing_slab_formwork_material'] = 'Roofing slab formwork material';
$lang['Balcony'] = 'Balcony';
$lang['Lattices'] = 'Lattices';
$lang['Gates_doors'] = 'Gates and Doors';
$lang['Stair_railings'] = 'Stair railings';
$lang['Building materials'] = 'Building materials';
$lang['Material'] = 'Material';
$lang['Safety regulations'] = 'Safety regulations';
$lang['Villa_Akhalsopeli_Batumi'] = 'Villa Akhalsopeli Batumi'; 
$lang['Villa_Akhalsopeli_Khelvachauri'] = 'Villa akhalsopeli khelvachauri' ; 
$lang['Maxinjauri_House'] = 'Maxinjauri House' ; 
$lang['Villa_Gonio'] = 'Villa Gonio ' ; 
$lang['Aliansi_Centro_Polis'] = 'Aliansi Centro Polis' ; 

$lang['School'] = 'School';
$lang['repair_text'] = '<h2><b> სარემონტო სამუშაოები</b></h2><p>ჩვენ ვასრულებთ, როგორც ბინის და სახლის რემონტს, ასევე ოფისების/კომერციული ფართების რემონტს.
</p>
<h3>როგორ ვმუშაობთ:</h3>
<p>
საწყის ეტაპზე, ვათანხმებთ დამკვეთთან შესასრულებელ სამუშაოებს და პერიოდს, შემდგომ მზადდება განფასება, სადაც დეტალურად არის აღწერილი შესასრულებელი სამუშაოების მოცულობა, შრომისა და მასალების თანხა. მომხმარებელთან ერთად, დეტალურად განვიხილავთ განფასებას და ამის შემდგომ ვიწყებთ სარემონტო სამუშაოებს.
ხორციელდება პროექტის მენეჯერის მიერ, მუდმივი კონტროლი სარემონტო სამუშაოების მიმდინარეობისას, მაღალი ხარისხის უზრუნველსაყოფად.
მომხმარებლის კმაყოფილების მიზნით, პროექტის მენეჯერი, ასევე ეხმარება დამკვეთს ხარისხიანი მასალების შერჩევაში (როგორიც არის: კაფელ-მეტლახი, შპალერის ქაღალდი,  და ა.შ.), რაც საბოლოო შედეგის ეფექტურობის გარანტია.
</p>
<br>
<h2><b>ხარისხი და გარანტიები:</b> </h2>
<h3>ხარისხი </h3>
<p>
მაქსიმალური ხარისხის მისაღებად, საჭიროა კომპეტენტური პროექტის მენეჯერის მუდმივი ზედამხედველობა, სარემონტო სამუშაოების პროცესში 
გამოცდილ ხელოსნებთან ერთად. სასურველია მაღალ ხარისხიანი  სამშენებლო მასალების შერჩევა  რაც დიდ გავლენას ახდენს საბოლოო შედეგზე. ამ მიზნით ჩვენ ვიყენებთ, საკმაოდ ცნობილ და ხარისხიან ბრენდებს, როგორიც არის: Knauf-ის თაბაშირ-მუყაოს ფილა, ჰაიდელბერგის ცემენტი, Firat-ისა და ფონდიტალის  მილგაყვანილობა და ა.შ.
კომპეტენტური პროექტის მენეჯერის, ხარისხიანი მასალებისა და გამოცდილი ხელოსნების კომბინაციით, ჩვენ ვქმნით მაღალ ხარისხის.</p>
<br>
<h3>გარანტიები</h3>
<p>
სარემონტო სამუშაოების დაწყებამდე, იდება ხელშეკრულება, სადაც დეტალურად არის გაწერილი სამუშაოს ხანგრძლივობა, შესასრულებელი სამუშაოები და შესასრულებელი სამუშაოების ფასები.
ჩვენთან შეთანხმებული გადასახადის თანხა, რემონტის პროცესში არ იზრდება.
</p>
<br>
<h3>თანხის გადახდა</h3>
<p>
თანხის გადახდა ხდება ეტაპობრივად, ხელშეკრულების საფუძველზე (საბანკო გადარიცხვით). სარემონტო სამუშაოების, მთლიანი ღირებულების 20%-ს იხდის მომხმარებელი სამუშაოების დაწყებიდან არაუგვიანეს მე-3 დღეს და ყოველი მომდევნო გადახდა (20%-ის ოდენობით), ხორციელდება გარკვეული სამუშაოების დასრულების შემდგომ.
</p>
<p>
მთლიანი ღირებულების ბოლო 15%-ს მომხმარებელი იხდის, სარემონტო სამუშაოების სრულად დამთავრების შემდგომ.
</p>
<h3>ჩვენ ვასრულებთ შემდეგი სახის სარემონტო სამუშაოებს: </h3>

<p>სადემონტაჟო სამუშაოები;</p>
<p>შენება: აგურით; ბლოკით;</p>
<p>საიზოლაციო სამუშაოები;</p>
<p>ელექტროგაყვანილობა და ვენტილაცია;</p>
<p>წყალმომარაგება ;გათბობა და გაგრილება;</p>
<p>ლესვა: ფითხით, ქვიშა,ცემენტით, როტბანდით;</p>
<p>მოჭიმული იატაკი: თვითსწორებადი, სტანდარტული;
სამალიარო სამუშაოები: ფითხით კედლის ზედაპირის მონტაჟი, შეღებვა, შპალერის გაკვრა;</p>
<p>კაფელ-მეტლახის სამუშაოები, მეტლახის მონტაჟი,
 მდფ-ის, პლასტმასისა და ხის პლინტუსის მონტაჟი;
ლამინატისა და პარკეტის მონტაჟი, ციკლოვკა;</p>
<p>საბრიზგი სამუშაოები;<p/>
<p>თაბაშირ-მუყაოს ფილების სამონტაჟო სამუშაოები: ჭერები, ტიხრები, ფრანგული გასაჭიმი ჭერის მონტაჟი(ბარისოლი)
ამსტრონგის ჭერის მონტაჟი, მეტალის, MDF-ისა და ხის კარებების მონტაჟი, მეტალის ნაკეთობების მონტაჟი და ღებვა, 
ვიტრაჟების მოწყობა, მეტალო-პლასტმასის სამონტაჟო სამუშაოები, სამშენებლო ნაგვის გატანა.';


$lang['project_title_lang'] = 'title_en';
$lang['project_short_text_lang'] = 'short_text_en';
$lang['project_full_text_lang'] = 'full_text_en';
$lang['project_address_lang'] = 'address_en';
$lang['about_text'] = 'about_text_en';
$lang['Electricity'] = 'Electricity';
$lang['Working hours'] = 'Working hours';
$lang['Monday-Friday'] = 'Monday-Friday';
$lang['Saturday'] = 'Saturday';
$lang['Our offer'] = 'Our offer';
$lang['We are a team'] = 'We are a team';
$lang['Service text'] = 'Service text';