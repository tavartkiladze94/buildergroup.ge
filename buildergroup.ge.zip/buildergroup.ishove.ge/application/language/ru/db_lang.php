<?php

$lang['read more'] = 'Читать дальше';
$lang['Home'] = 'Главная';
$lang['about conference'] = 'О конференции';